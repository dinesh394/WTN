import java.util.*;
class month
{
public static void main(String[] args) {
  Scanner s=new Scanner(System.in);
  int o=Integer.parseInt(args[0]);
  switch (o) {
    case 1:System.out.print("January");
    break;
    case 2:System.out.print("febrary");
    break;
    case 3:System.out.print("march");
    break;
    case 4:System.out.print("april");
    break;
    case 5:System.out.print("may");
    break;
    case 6:System.out.print("june");
    break;
    case 7:System.out.print("July");
    break;
    case 8:System.out.print("august");
    break;
    case 9:System.out.print("september");
    break;
    case 10:System.out.print("october");
    break;
    case 11:System.out.print("november");
    break;
    case 12:System.out.print("december");
    break;

  }
}
}
